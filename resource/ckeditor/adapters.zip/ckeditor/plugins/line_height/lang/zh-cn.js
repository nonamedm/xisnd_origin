﻿CKEDITOR.plugins.setLang('line_height', 'zh-cn', {
    label: '行距',
    panelTitle: '行距',
    panelTitle: '行距'
});