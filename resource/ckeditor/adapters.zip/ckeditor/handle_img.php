<?php

echo $_FILES[ 'upload_image' ][ 'tmp_name' ];

?>