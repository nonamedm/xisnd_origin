﻿CKEDITOR.plugins.setLang('line_height', 'en', {
    label: 'lineheight',
    panelTitle: 'line-height',
    panelTitle: 'line-height'
});