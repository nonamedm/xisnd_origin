CKEDITOR.plugins.setLang('line_height', 'ko-kr', {
    label: '문단높이',
    panelTitle: '문단높이',
    panelTitle: '문단높이'
});