/*
Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'image2', 'sr-latn', {
	alt: 'Alternativni tekst',
	btnUpload: 'Pošalji na server',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Info slike',
	lockRatio: 'Zaključaj odnos',
	menu: 'Osobine slika',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Resetuj veličinu',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Osobine slika',
	uploadTab: 'Pošalji',
	urlMissing: 'Image source URL is missing.', // MISSING
	altMissing: 'Alternative text is missing.' // MISSING
} );
